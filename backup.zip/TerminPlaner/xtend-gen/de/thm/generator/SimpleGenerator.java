package de.thm.generator;

import Terminplaner.Kalender;
import Terminplaner.Nutzer;
import Terminplaner.Termin;
import com.google.common.collect.Iterables;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class SimpleGenerator {
  /**
   * The path where to generate the Java files.
   */
  public static final String SOURCE_FOLDER_PATH = "src-gen/";
  
  /**
   * The base package name.
   */
  public static final String PACKAGE = "de.thm.xtendEMF.";
  
  public static final String PACKAGE_PATH = ("/" + SimpleGenerator.PACKAGE.replaceAll("\\.", "/"));
  
  public void doGenerate(final Resource resourceEcore, final IProject project, final IProgressMonitor progressMonitor) {
    try {
      progressMonitor.beginTask("Generating Java code", 2);
      progressMonitor.subTask("Creating folders");
      IFolder folder = project.getFolder(SimpleGenerator.SOURCE_FOLDER_PATH);
      boolean _exists = folder.exists();
      boolean _not = (!_exists);
      if (_not) {
        NullProgressMonitor _nullProgressMonitor = new NullProgressMonitor();
        folder.create(true, true, _nullProgressMonitor);
      }
      folder = project.getFolder((SimpleGenerator.SOURCE_FOLDER_PATH + "de"));
      boolean _exists_1 = folder.exists();
      boolean _not_1 = (!_exists_1);
      if (_not_1) {
        NullProgressMonitor _nullProgressMonitor_1 = new NullProgressMonitor();
        folder.create(true, true, _nullProgressMonitor_1);
      }
      folder = project.getFolder((SimpleGenerator.SOURCE_FOLDER_PATH + "/de/thm"));
      boolean _exists_2 = folder.exists();
      boolean _not_2 = (!_exists_2);
      if (_not_2) {
        NullProgressMonitor _nullProgressMonitor_2 = new NullProgressMonitor();
        folder.create(true, true, _nullProgressMonitor_2);
      }
      folder = project.getFolder((SimpleGenerator.SOURCE_FOLDER_PATH + "/de/thm/xtendEMF"));
      boolean _exists_3 = folder.exists();
      boolean _not_3 = (!_exists_3);
      if (_not_3) {
        NullProgressMonitor _nullProgressMonitor_3 = new NullProgressMonitor();
        folder.create(true, true, _nullProgressMonitor_3);
      }
      folder = project.getFolder(((SimpleGenerator.SOURCE_FOLDER_PATH + SimpleGenerator.PACKAGE_PATH) + "entities"));
      boolean _exists_4 = folder.exists();
      boolean _not_4 = (!_exists_4);
      if (_not_4) {
        NullProgressMonitor _nullProgressMonitor_4 = new NullProgressMonitor();
        folder.create(true, true, _nullProgressMonitor_4);
      }
      IFolder entityFolder = project.getFolder(((SimpleGenerator.SOURCE_FOLDER_PATH + SimpleGenerator.PACKAGE_PATH) + "entities"));
      progressMonitor.subTask("Generating Entities");
      Iterable<Kalender> _filter = Iterables.<Kalender>filter(IteratorExtensions.<EObject>toIterable(resourceEcore.getAllContents()), Kalender.class);
      for (final Kalender e : _filter) {
        EList<Nutzer> _nutzer = e.getNutzer();
        for (final Nutzer p : _nutzer) {
          {
            CharSequence content = this.compileEntities(p);
            EList<Termin> _termine = p.getTermine();
            String _plus = (_termine + ".txt");
            this.createFile(entityFolder, _plus, 
              false, content, progressMonitor);
          }
        }
      }
      progressMonitor.done();
    } catch (final Throwable _t) {
      if (_t instanceof Exception) {
        final Exception ex = (Exception)_t;
        ex.printStackTrace();
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
  }
  
  public CharSequence compileEntities(final Nutzer e) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Hier steht einiges �ber ITems muss ich sagen:");
    _builder.newLine();
    _builder.newLine();
    _builder.append("Konkret geht es um dieses ITem: �e.productName� Da");
    _builder.newLine();
    _builder.append("bin ich mir wirklich sicher!");
    _builder.newLine();
    return _builder;
  }
  
  public boolean isString(final EAttribute a) {
    int _classifierID = a.getEAttributeType().getClassifierID();
    return (_classifierID == EcorePackage.ESTRING);
  }
  
  /**
   * Creates a file (containing the content-CharSequence) within the given IFolder.
   */
  public void createFile(final IFolder folder, final String fileName, final boolean overrideFile, final CharSequence content, final IProgressMonitor progressMonitor) {
    try {
      boolean _isCanceled = progressMonitor.isCanceled();
      if (_isCanceled) {
        throw new RuntimeException("Progress canceled");
      }
      boolean _exists = folder.exists();
      boolean _not = (!_exists);
      if (_not) {
        folder.create(true, true, null);
      }
      IFile iFile = folder.getFile(fileName);
      if ((iFile.exists() && true)) {
        iFile.delete(true, null);
      }
      boolean _exists_1 = iFile.exists();
      boolean _not_1 = (!_exists_1);
      if (_not_1) {
        String formattedCode = content.toString();
        byte[] bytes = null;
        if ((formattedCode != null)) {
          bytes = formattedCode.getBytes();
        } else {
          bytes = content.toString().getBytes();
          System.err.println((("File " + fileName) + " could not be formatted."));
        }
        InputStream source = new ByteArrayInputStream(bytes);
        iFile.create(source, true, null);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
